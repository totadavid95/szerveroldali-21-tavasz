<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php if(View::hasSection('title')): ?>
            <?php echo $__env->yieldContent('title'); ?>
        <?php else: ?>
            Laravel Alkalmazás
        <?php endif; ?>
    </title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.css')); ?>">
</head>
<body>
    <header class="mb-3">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="index.html">
                <img src="<?php echo e(asset('images/bootstrap.svg')); ?>" width="30" height="30" class="d-inline-block align-top" alt="Logo">
                Blog
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-nav" aria-controls="main-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="main-nav">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.html">Nyitólap</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>

    <main>
        <?php echo $__env->yieldContent('main-content'); ?>
    </main>

    <footer>
        <div class="container">
            <hr>
            <div class="d-flex flex-column align-items-center">
                <div>
                    <span class="small">Alapszintű Blog</span>
                    <span class="mx-1">·</span>
                    <span class="small">Laravel <?php echo e(app()->version()); ?></span>
                    <span class="mx-1">·</span>
                    <span class="small">PHP <?php echo e(phpversion()); ?></span>
                </div>

                <div>
                    <span class="small">Szerveroldali webprogramozás 2020-21-2</span>
                </div>
            </div>
        </div>
    </footer>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\2020_21_2\Szerveroldali\gyakanyagok\szerveroldali-21-tavasz\pentek\laravel\pentek\resources\views/layouts/base.blade.php ENDPATH**/ ?>