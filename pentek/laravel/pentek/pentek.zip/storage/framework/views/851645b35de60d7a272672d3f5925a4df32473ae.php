<?php $__env->startSection('main-content'); ?>
    
    <?php
        echo '<p>Teszt</p>';
    ?>

    <?= '<p>Teszt</p>' ?>

    
    <?php
        echo '<p>Teszt</p>';

        $name = 'David';

        echo '<p>' . $name . '</p>';

        $number = 1;
    ?>

    
    <?php echo e($name); ?>


    <?php
        if (isset($name)) {
            echo '<p>A $name létezik</p>';
        }
    ?>

    <?php if(isset($name)): ?>
        <p>A $name létezik</p>
    <?php endif; ?>

    
    <?php if($number == 1): ?>
        <p>A $number értéke 1</p>
    <?php elseif($number == 2): ?>
        <p>A $number értéke 2</p>
    <?php else: ?>
        <p>A $number értéke se nem 1, se nem 2</p>
    <?php endif; ?>

    <?php switch($number):
        case (1): ?>
            <p>A $number értéke 1</p>
            <?php break; ?>
        <?php case (2): ?>
            <p>A $number értéke 2</p>
            <?php break; ?>
        <?php default: ?>
            <p>A $number értéke se nem 1, se nem 2</p>
    <?php endswitch; ?>

    
    <ul>
        <?php for($i = 0; $i < 5; $i++): ?>
            <li>for ciklus: <?php echo e($i); ?></li>
        <?php endfor; ?>
    </ul>

    <?php
        $fruits = ['alma', 'szilva', 'barack'];
        $fruits_empty = [];
    ?>

    <ul>
        <?php $__currentLoopData = $fruits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($fruit); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <ul>
        <?php $__currentLoopData = $fruits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($loop->iteration); ?>. <?php echo e($fruit); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <ul>
        <?php $__currentLoopData = $fruits_empty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($loop->iteration); ?>. <?php echo e($fruit); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $fruits_empty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li><?php echo e($loop->iteration); ?>. <?php echo e($fruit); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <li>A tömb üres.</li>
        <?php endif; ?>
    </ul>

    <?php if(empty($fruits_empty)): ?>
        <p>A $fruits_empty üres</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2020_21_2\Szerveroldali\gyakanyagok\szerveroldali-21-tavasz\pentek\laravel\pentek\resources\views/welcome.blade.php ENDPATH**/ ?>