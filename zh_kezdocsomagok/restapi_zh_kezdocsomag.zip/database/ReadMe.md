# Adatbázis mappa

A debugoláshoz célszerű a [DB Browser for SQLite](https://sqlitebrowser.org/dl/) használata.
